from django.contrib import admin
from .models import Voluntario, Evento

admin.site.register(Voluntario)
admin.site.register(Evento)